### 作者：郭若垚，班级：二（2），住：南京市
用pickle、base64和struct实现加密文件