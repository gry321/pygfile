### 作者：郭若垚，班级：二（2），住：南京市
用pickle、base64和struct实现加密文件
提示：
如果报错 TypeError: a bytes-like object is required, not 'list' 就是多了
如果报错 TypeError: a bytes-like object is required, not 'int' 那就是少了